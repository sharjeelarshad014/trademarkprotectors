<?php
   $brandName= "Trademark Protectors";
   $brandShortCapsName= "";
   $brandShortName= "";
   $brandTFN= "";
   $brandLocal= "";
   $brandDomain= "";
   $brandAddress= "";
   $cversion= "1.1";
?>