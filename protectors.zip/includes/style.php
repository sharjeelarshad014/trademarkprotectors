<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no">
<link rel="preload" href="/staging/assets/css/style.min.css" as="style">
<link rel="preload" href="/staging/assets/icons/fonts/xicons.ttf?e98pql" as="font" type="font/woff2" crossorigin>
<link rel="icon" type="image/x-icon" size="16x16" href="/staging/favicon.ico">
<link rel="stylesheet" type="text/css" href="/staging/assets/css/style.min.css"/>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">