<div class="c-popup">
	<div class="overlay js-close-popup"></div>
	<section class="popup popup-centered wd-995 popup-style1 show-letter">
		<div class="popup-head"></div>
		<div class="popup-wrap">
			<a href="javascript:;" class="c-close js-close-popup">✖</a>
			<div class="popupContent">
				<img src="/staging/assets/img/letters/letter-1.jpg" alt="">
			</div>
		</div>
		<div class="popup-foot"></div>
	</section>
</div>