<footer class="footer">
	<div class="footer-content">
			<div class="container">
				<div class="row">
					<div class="col-6 col-md-4">
						<div class="logo-widget">
							<a href="/staging/">
								<img src="/staging/assets/img/brand/logo-black.png" alt="">
							</a>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
							<div class="contact-list sty1">
								<ul>
									<li class="icon-sty1">
										<a href="javascript:;"><i class="ic-3"></i></a>
									</li>
									<li class="icon-sty1">
										<a href="javascript:;"><i class="ic-4"></i></a>
									</li>
									<li class="icon-sty1">
										<a href="javascript:;"><i class="ic-5"></i></a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-6 col-md-2">
						<div class="link-widget">
							<h5 class="h5">Useful Links</h5>
							<ul>
								<li><a href="/staging/">Home</a></li>
								<li><a href="/staging/about-us/">About Us</a></li>
								<li><a href="javascript:;">FAQ's</a></li>
								<li><a href="javascript:;">Contact Us</a></li>
							</ul>
						</div>
					</div>
					<div class="col-6 col-md-3">
						<div class="link-widget">
							<h5 class="h5">Our Expertise</h5>
							<ul>
								<li><a href="javascript:;">Trademark Registration</a></li>
								<li><a href="javascript:;">Trademark Renewal</a></li>
								<li><a href="javascript:;">Trademark Search</a></li>
								<li><a href="javascript:;">Copyright Registration</a></li>
							</ul>
						</div>
					</div>
					<div class="col-6 col-md-3">
						<div class="link-widget">
							<h5 class="h5">Quick Links</h5>
							<ul>
								<li><a href="javascript:;">+971 23 456 7680</a></li>
								<li><a href="javascript:;">info@trademarkprotector.com</a></li>
								<li><a href="javascript:;">sales@trademarkprotector.com</a></li>
								<li><a href="javascript:;">TALK TO A CONSULTANT</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	<div class="sec-copyright">
		<div class="container">
			<div class="fflex">
				<p>©2024  |   Trademark Protectors. All Rights Reserved</p>
				<ul class="copyright-links">
					<li><a href="javascript:;">Privacy Policy</a></li>
					<li><a href="/staging/contact-us/">Contact Us</a></li>
				</ul>
			</div>
		</div>
	</div>
</footer>